#!/usr/bin/env bash
set -euo pipefail
REPO="https://github.com/TelegramMessenger/Telegram-Android.git"
DEST="vendor/Telegram-Android"
mkdir -p vendor
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" pull --ff-only
else
  git clone --depth 1 "$REPO" "$DEST"
fi
echo "Telegram Android source is in: $DEST"

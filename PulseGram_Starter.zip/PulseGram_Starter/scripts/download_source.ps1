$ErrorActionPreference = "Stop"
$repo = "https://github.com/TelegramMessenger/Telegram-Android.git"
$dest = "vendor/Telegram-Android"
New-Item -ItemType Directory -Force -Path "vendor" | Out-Null
if (Test-Path "$dest/.git") {
  git -C $dest pull --ff-only
} else {
  git clone --depth 1 $repo $dest
}
Write-Host "Telegram Android source is in: $dest"
